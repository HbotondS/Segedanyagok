#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>


bool bpm(bool** bpGraph, int u, bool seen[], int matchR[], int numberOfJobs) {
    for (int i = 0; i < numberOfJobs; ++i) {
        if (bpGraph[u][i] && !seen[i]) {
            seen[i] = true;
            if (matchR[i] < 0 || bpm(bpGraph, matchR[i], seen, matchR, numberOfJobs)) {
                matchR[i] = u;
                return true;
            }
        }
    }
    return false;
}

int maxBPM(bool** bpGraph, int numberOfJobs, int numberOfApplicant) {

    int matchR[numberOfJobs];
    for (int i = 0; i < numberOfJobs; ++i) {
        matchR[i] = -1;
    }

    int result = 0;
    for (int i = 0; i < numberOfApplicant; ++i) {
        bool seen[numberOfJobs];
        for (int j = 0; j < numberOfJobs; ++j) {
            seen[j] = false;
        }

        if (bpm(bpGraph, i, seen, matchR, numberOfApplicant)) {
            result++;
        }
    }

    return result;
}

int main() {
    FILE* in;
    if( !(in = fopen("in.txt", "r"))) {
        printf("The file doesn't exist.");
        return 1;
    }
    int numberOfJobs, numberOfApplicants, numberOfEdges;
    fscanf(in, "%d%d%d", &numberOfJobs, &numberOfApplicants, &numberOfEdges);
    bool** bpGraph = (bool**)calloc(numberOfJobs, sizeof(bool*));
    for (int i = 0; i < numberOfJobs; ++i) {
        bpGraph[i] = (bool*)calloc(numberOfJobs, sizeof(bool));
    }

    int node1, node2;
    for (int i = 0; i < numberOfEdges; ++i) {
        fscanf(in, "%d%d", &node1, &node2);
        bpGraph[node1][node2] = 1;
    }

    printf("Maximum number of applicants that can get job is: %d", maxBPM(bpGraph, numberOfJobs, numberOfApplicants));

    fclose(in);
    for (int i = 0; i < numberOfJobs; ++i) {
        free(bpGraph[i]);
    }
    free(bpGraph);
    return 0;
}